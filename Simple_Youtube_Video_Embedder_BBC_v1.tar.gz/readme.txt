[hr]
[center][color=teal][size=16pt][b]Simple Youtube Video Embedder/BBC[/b][/size][/color]
[u](For SMF 2.0.x)[/u]
Mod by xPandax | [url=http://custom.simplemachines.org/mods/index.php?action=profile;u=158159]Other Mods[/url] by xPandax
[/center]
[hr]
[center][url]Link to Mod[/url] | [url]Support Thread for this Mod[/url][/center]


[color=purple][size=12pt][b]Features[/b][/size][/color]
[list type=decimal]
[li]This mod parses & displays youtube videos automatically. This mod supports both 'youtube.com' & 'youtu.be' links and also http/https links. This mod also adds a 'youtube' BBC.[/li]
[li]Since youtube video links are automatically parsed & displayed, there is no need to use the 'youtube' tags. At the same time, youtube links & video id's wrapped within 'youtube' tags also work. In addition to these features, this mod supports the following format also which was used by some old mods.
[list]
[li][u][youtube]yVpbFMhOAwE[/youtube][/u]
[/li]
[/list]
[/li]
[li]It works on all browsers (with/without flash). If flash player is not available, then this mod displays the videos using HTML5.[/li]
[li]If you were using some other mod that used 'youtube' tags, then this mod should parse & display those youtube links too.[/li]
[li]This mod does 'not' add any extra tables in the database or install any extra files, its light weight & pretty fast. :)[/li]
[/list]


[color=purple][size=12pt][b]Who should use this Mod[/b][/size][/color]
If you are one of among the people who use only youtube videos in your forum then this is the mod that you're looking for.


[color=purple][size=12pt][b]Why you should use this Mod[/b][/size][/color]
Since this mod does does 'not' add any extra tables in the database or install any extra files, its light weight & pretty fast.


[color=purple][size=12pt][b]How-To[/b][/size][/color]
Youtube video links are parsed & displayed automatically.


[color=purple][size=12pt][b]Supported Themes[/b][/size][/color]
Works on all the themes without any custom edits!


[color=purple][size=12pt][b]Supported SMF Versions[/b][/size][/color]
Tested on fresh installation of 2.0.4.


[color=purple][size=12pt][b]Supported Languages[/b][/size][/color]
NA.


[color=purple][size=12pt][b]Support[/b][/size][/color]
If you need support with this mod, please use the [url]Support Thread for this Mod[/url].

 
[color=purple][size=12pt][b]Changelog[/b][/size][/color]
[b]v1.0[/b] - Initial release.


[hr]
[center]
[url=http://creativecommons.org/licenses/by-sa/3.0/deed.en_US][img]http://i.creativecommons.org/l/by-sa/3.0/88x31.png[/img][/url]
This work is licensed under a [url=http://creativecommons.org/licenses/by-sa/3.0/deed.en_US]Creative Commons Attribution-ShareAlike 3.0 Unported License[/url].
[/center]
